// reload the webpage every five minutes, time is in milliseconds
setTimeout(function() { window.location=window.location;},((1000*60)*5));
